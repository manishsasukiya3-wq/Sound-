package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.SessionManager
import com.example.data.model.User
import com.example.data.remote.SupabaseClientProvider
import com.example.data.repository.Resource
import com.example.data.repository.TestMitraRepository
import com.example.ui.components.MitraPrimaryButton
import com.example.ui.theme.MitraBgLight
import com.example.ui.theme.MitraBorder
import com.example.ui.theme.MitraError
import com.example.ui.theme.MitraErrorLight
import com.example.ui.theme.MitraGreen
import com.example.ui.theme.MitraNavyDark
import com.example.ui.theme.MitraNavyPrimary
import com.example.ui.theme.MitraOrange
import com.example.ui.theme.MitraTextMuted
import com.example.ui.theme.MitraTextPrimary
import com.example.ui.theme.MitraTextSecondary
import kotlinx.coroutines.launch
import com.example.util.AppSoundManager

@Composable
fun LoginScreen(
    repository: TestMitraRepository,
    sessionManager: SessionManager,
    clientProvider: SupabaseClientProvider,
    onLoginSuccess: (User) -> Unit
) {
    var mobileNumber by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showSwitchDeviceDialog by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        containerColor = MitraBgLight,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = Modifier
            .fillMaxSize()
            .testTag("login_screen")
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MitraBgLight)
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .imePadding()
                    .padding(horizontal = 20.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Header Logo Card
                Surface(
                    modifier = Modifier.size(98.dp),
                    shape = CircleShape,
                    color = Color.White,
                    shadowElevation = 6.dp
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_test_mitra_logo),
                            contentDescription = "TEST MITRA Logo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "TEST MITRA",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MitraNavyPrimary,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "Online MCQ Test Portal",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MitraGreen
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Login Form Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(22.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Login to Your Account",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MitraTextPrimary,
                            lineHeight = 22.sp
                        )

                        // Mobile Number Input
                        OutlinedTextField(
                            value = mobileNumber,
                            onValueChange = { input ->
                                if (input.all { it.isDigit() } && input.length <= 15) {
                                    mobileNumber = input
                                    errorMessage = null
                                }
                            },
                            label = { Text("Mobile Number") },
                            placeholder = { Text("Enter mobile number") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Phone,
                                    contentDescription = null,
                                    tint = MitraNavyPrimary
                                )
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Phone,
                                imeAction = ImeAction.Next
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("mobile_number_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MitraNavyPrimary,
                                unfocusedBorderColor = MitraBorder
                            )
                        )

                        // Password Input
                        OutlinedTextField(
                            value = password,
                            onValueChange = {
                                password = it
                                errorMessage = null
                            },
                            label = { Text("Password") },
                            placeholder = { Text("Enter password") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = MitraNavyPrimary
                                )
                            },
                            trailingIcon = {
                                IconButton(onClick = { AppSoundManager.playClick(); isPasswordVisible = !isPasswordVisible }) {
                                    Icon(
                                        imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                                        tint = MitraTextMuted
                                    )
                                }
                            },
                            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Password,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    focusManager.clearFocus()
                                }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("password_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MitraNavyPrimary,
                                unfocusedBorderColor = MitraBorder
                            )
                        )

                        // Error Message Display
                        if (!errorMessage.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MitraErrorLight,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = errorMessage!!,
                                    color = MitraError,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(12.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        // Login Action Button
                        MitraPrimaryButton(
                            text = "Login",
                            onClick = { AppSoundManager.playClick();
                                focusManager.clearFocus()
                                val cleanMobile = mobileNumber.trim()
                                val cleanPassword = password.trim()

                                if (cleanMobile.isBlank()) {
                                    errorMessage = "Please enter your mobile number"
                                    return@MitraPrimaryButton
                                }
                                if (cleanPassword.isBlank()) {
                                    errorMessage = "Please enter your password"
                                    return@MitraPrimaryButton
                                }

                                isLoading = true
                                errorMessage = null
                                scope.launch {
                                    val currentDeviceId = sessionManager.getDeviceId()
                                    when (val result = repository.login(cleanMobile, cleanPassword, currentDeviceId, forceSwitchDevice = false)) {
                                        is Resource.Success -> {
                                            isLoading = false
                                            sessionManager.saveUser(result.data)
                                            AppSoundManager.playLoginSuccess()
                                            onLoginSuccess(result.data)
                                        }
                                        is Resource.Error -> {
                                            isLoading = false
                                            errorMessage = if (result.isNetworkError) {
                                                "No internet connection. Please check your network and retry."
                                            } else {
                                                result.message
                                            }
                                            if (result.isDeviceActiveOnAnotherPhone) {
                                                showSwitchDeviceDialog = true
                                            }
                                        }
                                        else -> {
                                            isLoading = false
                                        }
                                    }
                                }
                            },
                            isLoading = isLoading,
                            icon = Icons.Default.Login,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "login_button"
                        )
                    }
                }
            }
        }
    }

    // Switch Device Confirmation Dialog
    if (showSwitchDeviceDialog) {
        AlertDialog(
            onDismissRequest = { showSwitchDeviceDialog = false },
            shape = RoundedCornerShape(18.dp),
            containerColor = Color.White,
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = MitraOrange,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Account Active on Other Device",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MitraNavyDark,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "This account is currently active on another phone.\n\nIf you uninstalled the app from your old phone or switched to this new phone, you can activate this phone as your active device now.",
                    fontSize = 13.sp,
                    color = MitraTextPrimary,
                    textAlign = TextAlign.Start,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                MitraPrimaryButton(
                    text = "Activate on this Device",
                    onClick = { AppSoundManager.playClick();
                        showSwitchDeviceDialog = false
                        isLoading = true
                        errorMessage = null
                        scope.launch {
                            val cleanMobile = mobileNumber.trim()
                            val cleanPassword = password.trim()
                            val currentDeviceId = sessionManager.getDeviceId()
                            when (val result = repository.login(cleanMobile, cleanPassword, currentDeviceId, forceSwitchDevice = true)) {
                                is Resource.Success -> {
                                    isLoading = false
                                    sessionManager.saveUser(result.data)
                                    AppSoundManager.playLoginSuccess()
                                    onLoginSuccess(result.data)
                                }
                                is Resource.Error -> {
                                    isLoading = false
                                    errorMessage = result.message
                                }
                                else -> {
                                    isLoading = false
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { AppSoundManager.playClick(); showSwitchDeviceDialog = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Cancel",
                        color = MitraTextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        )
    }
}
