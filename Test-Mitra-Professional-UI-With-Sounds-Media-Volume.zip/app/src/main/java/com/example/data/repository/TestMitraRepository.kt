package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.model.CreatePassageRequest
import com.example.data.model.CreateQuestionRequest
import com.example.data.model.CreateResultRequest
import com.example.data.model.CreateTestRequest
import com.example.data.model.CreateUserRequest
import com.example.data.model.EnrichedResult
import com.example.data.model.QuestionItem
import com.example.data.model.ResultItem
import com.example.data.model.ResultModel
import com.example.data.model.TestItem
import com.example.data.model.TestModel
import com.example.data.model.UpdatePassageRequest
import com.example.data.model.UpdateQuestionRequest
import com.example.data.model.UpdateResultRequest
import com.example.data.model.UpdateTestRequest
import com.example.data.model.UpdateTestStatusRequest
import com.example.data.model.UpdateUserDeviceRequest
import com.example.data.model.UpdateUserRequest
import com.example.data.model.User
import com.example.data.remote.SupabaseClientProvider
import com.example.data.remote.SupabaseStorageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.Response
import java.io.IOException

sealed class Resource<out T> {
    data class Success<out T>(val data: T) : Resource<T>()
    data class Error(
        val message: String,
        val isNetworkError: Boolean = false,
        val isDeviceActiveOnAnotherPhone: Boolean = false
    ) : Resource<Nothing>()
    data object Loading : Resource<Nothing>()
}

class TestMitraRepository(
    private val clientProvider: SupabaseClientProvider
) {
    private val usersNameCache = mutableMapOf<Long, String>()

    private fun extractErrorMessage(response: Response<*>): String {
        return try {
            val errorBody = response.errorBody()?.string()
            if (!errorBody.isNullOrBlank()) {
                if (errorBody.contains("JWT expired") || errorBody.contains("invalid claim")) {
                    "Session or API Key expired. Please check Supabase Settings."
                } else if (errorBody.contains("Failed to connect") || errorBody.contains("hostname")) {
                    "Unable to connect to Supabase URL. Please check network."
                } else {
                    errorBody.take(200)
                }
            } else {
                "Server responded with error code: ${response.code()}"
            }
        } catch (_: Exception) {
            "Network error (HTTP ${response.code()})"
        }
    }

    suspend fun checkConnection(): Resource<Boolean> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase credentials not configured. Please set URL & Anon Key.")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getTests(select = "id,test_name,duration,is_active", order = "id.asc")
            if (response.isSuccessful) {
                Resource.Success(true)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection or unable to reach Supabase: ${e.localizedMessage}", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Connection error: ${e.localizedMessage ?: "Unknown error"}")
        }
    }

    suspend fun login(
        mobileNumber: String,
        password: String,
        currentDeviceId: String,
        forceSwitchDevice: Boolean = false
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase URL and API Key must be configured first.")
        }
        try {
            val api = clientProvider.getApiService()
            val cleanMobile = mobileNumber.trim()
            val response = api.getUserByMobile("eq.$cleanMobile")
            if (!response.isSuccessful) {
                val detailedError = extractErrorMessage(response)
                return@withContext Resource.Error(detailedError)
            }

            val users = response.body().orEmpty()
            if (users.isEmpty()) {
                return@withContext Resource.Error("User not found or invalid credentials")
            }

            val matchedUser = users.firstOrNull {
                it.password?.trim() == password.trim()
            }

            if (matchedUser == null) {
                return@withContext Resource.Error("Invalid password")
            }

            if (matchedUser.deviceId?.trim() == "DEACTIVATED") {
                return@withContext Resource.Error("This account has been deactivated by Super Admin.")
            }

            // Single Device Login Restriction for Students:
            if (!matchedUser.isTeacherOrAdmin) {
                val activeDevice = matchedUser.deviceId?.trim()
                val thisDevice = currentDeviceId.trim()

                // If active on another phone/device and user did not explicitly request device switch
                if (!activeDevice.isNullOrBlank() && activeDevice != thisDevice && !forceSwitchDevice) {
                    return@withContext Resource.Error(
                        message = "This account is already active on another device. Please logout from the previous device first, or activate this device.",
                        isDeviceActiveOnAnotherPhone = true
                    )
                }

                // Register current device ID in Supabase to make this device the single active device
                try {
                    api.updateUserDeviceId("eq.${matchedUser.id}", UpdateUserDeviceRequest(thisDevice))
                } catch (_: Exception) {
                    // Fail silently if column update issues
                }
            }

            Resource.Success(matchedUser.copy(deviceId = currentDeviceId))
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Login failed: ${e.localizedMessage ?: "Unable to connect to Supabase"}")
        }
    }

    suspend fun clearUserDeviceId(userId: Long): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured() || userId <= 0) {
            return@withContext Resource.Success(Unit)
        }
        try {
            val api = clientProvider.getApiService()
            // Reset device_id to empty in Supabase so another device can login cleanly
            api.updateUserDeviceId("eq.$userId", UpdateUserDeviceRequest(""))
            Resource.Success(Unit)
        } catch (_: Exception) {
            Resource.Success(Unit)
        }
    }

    suspend fun verifyUserSession(userId: Long, expectedDeviceId: String?): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured() || userId <= 0) {
            return@withContext Resource.Error("Session invalid")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getUserById("eq.$userId")
            if (!response.isSuccessful) {
                return@withContext Resource.Error("Account deleted")
            }
            val user = response.body()?.firstOrNull()
            if (user == null) {
                return@withContext Resource.Error("Account deleted")
            }
            if (user.deviceId?.trim() == "DEACTIVATED") {
                return@withContext Resource.Error("Account deactivated by Super Admin")
            }
            if (!user.isTeacherOrAdmin && !expectedDeviceId.isNullOrBlank()) {
                val userDev = user.deviceId?.trim()
                if (!userDev.isNullOrBlank() && userDev != expectedDeviceId.trim()) {
                    return@withContext Resource.Error("Logged in on another device")
                }
            }
            Resource.Success(user)
        } catch (e: IOException) {
            Resource.Error("Network error", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Session error")
        }
    }

    suspend fun getAllUsers(): Resource<List<User>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getAllUsers()
            if (response.isSuccessful) {
                val users = response.body().orEmpty()
                users.forEach { u ->
                    if (u.id != null) {
                        usersNameCache[u.id] = u.name ?: u.mobileNumber
                    }
                }
                Resource.Success(users)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load users: ${e.localizedMessage}")
        }
    }

    suspend fun registerUser(
        name: String,
        mobileNumber: String,
        password: String,
        role: String = "student",
        callerUser: User? = null
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        // Security Authorization: Only Super Admin can register users/students/admins
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can add users.")
        }
        val cleanName = name.trim()
        val cleanMobile = mobileNumber.trim()
        val cleanPassword = password.trim()
        val cleanRole = if (role.equals("admin", ignoreCase = true) || role.equals("teacher", ignoreCase = true)) "admin" else "student"

        if (cleanName.isBlank()) {
            val label = if (cleanRole == "admin") "Admin Name" else "Student Name"
            return@withContext Resource.Error("$label is required")
        }
        if (cleanMobile.length != 10 || !cleanMobile.all { it.isDigit() }) {
            return@withContext Resource.Error("Valid 10-digit mobile number required")
        }
        if (cleanPassword.isBlank()) {
            return@withContext Resource.Error("Password is required")
        }

        try {
            val api = clientProvider.getApiService()
            val checkResp = api.getUserByMobile("eq.$cleanMobile")
            if (checkResp.isSuccessful && !checkResp.body().isNullOrEmpty()) {
                return@withContext Resource.Error("This mobile number is already registered")
            }

            val req = CreateUserRequest(
                name = cleanName,
                mobileNumber = cleanMobile,
                password = cleanPassword,
                role = cleanRole,
                isSuperAdmin = false
            )
            val response = api.createUser(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: User(name = cleanName, mobileNumber = cleanMobile, role = cleanRole, isSuperAdmin = false)
                if (created.id != null) {
                    usersNameCache[created.id] = created.name ?: created.mobileNumber
                }
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save user.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to add user: ${e.localizedMessage}")
        }
    }

    suspend fun updateUser(
        userId: Long,
        name: String,
        password: String? = null,
        callerUser: User? = null,
        mobileNumber: String? = null
    ): Resource<User> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can edit users.")
        }
        val cleanName = name.trim()
        if (cleanName.isBlank()) {
            return@withContext Resource.Error("Name is required")
        }
        val cleanMobile = mobileNumber?.trim()?.ifBlank { null }
        if (cleanMobile != null) {
            if (cleanMobile.length != 10 || !cleanMobile.all { it.isDigit() }) {
                return@withContext Resource.Error("Enter valid 10-digit mobile number")
            }
        }
        val cleanPassword = password?.trim()?.ifBlank { null }

        try {
            val api = clientProvider.getApiService()
            // If changing mobile number, check if it's already used by another user
            if (cleanMobile != null) {
                val existingUsers = try {
                    val resp = api.getUserByMobile("eq.$cleanMobile")
                    if (resp.isSuccessful) resp.body().orEmpty() else emptyList()
                } catch (_: Exception) {
                    emptyList()
                }
                val duplicate = existingUsers.firstOrNull { it.id != userId }
                if (duplicate != null) {
                    return@withContext Resource.Error("This mobile number is already registered")
                }
            }

            val req = UpdateUserRequest(
                name = cleanName,
                mobileNumber = cleanMobile,
                password = cleanPassword
            )
            val response = api.updateUser("eq.$userId", req)
            if (response.isSuccessful) {
                val updated = response.body()?.firstOrNull() ?: User(id = userId, name = cleanName, mobileNumber = cleanMobile ?: "")
                usersNameCache[userId] = cleanName
                Resource.Success(updated)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to update user.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update user: ${e.localizedMessage}")
        }
    }

    suspend fun deleteUser(userId: Long, callerUser: User? = null): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can delete users.")
        }
        if (userId == 1L || (callerUser != null && userId == callerUser.id)) {
            return@withContext Resource.Error("Cannot delete Super Admin account")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.deleteUser("eq.$userId")
            if (response.isSuccessful) {
                usersNameCache.remove(userId)
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete user: ${e.localizedMessage}")
        }
    }

    suspend fun toggleAdminActiveStatus(
        adminId: Long,
        deactivate: Boolean,
        callerUser: User? = null
    ): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can activate/deactivate admins.")
        }
        if (adminId == 1L) {
            return@withContext Resource.Error("Cannot deactivate Super Admin.")
        }
        try {
            val api = clientProvider.getApiService()
            val newDeviceId = if (deactivate) "DEACTIVATED" else ""
            val response = api.updateUserDeviceId("eq.$adminId", UpdateUserDeviceRequest(newDeviceId))
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update admin status: ${e.localizedMessage}")
        }
    }

    suspend fun getTests(): Resource<List<TestItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getTests(order = "id.desc")
            if (response.isSuccessful) {
                val tests = response.body().orEmpty().sortedByDescending { it.id ?: 0L }
                Resource.Success(tests)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load tests: ${e.localizedMessage}")
        }
    }

    suspend fun updateTestStatus(testId: Long, isActive: Boolean): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.updateTestStatus("eq.$testId", UpdateTestStatusRequest(isActive))
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update test status: ${e.localizedMessage}")
        }
    }

    suspend fun getAllQuestions(): Resource<List<QuestionItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getAllQuestions()
            if (response.isSuccessful) {
                Resource.Success(response.body().orEmpty())
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load questions: ${e.localizedMessage}")
        }
    }

    suspend fun getQuestionsForTest(testId: Long): Resource<List<QuestionItem>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val response = api.getQuestionsForTest("eq.$testId")
            if (response.isSuccessful) {
                val questions = response.body().orEmpty().sortedBy { it.id ?: 0L }
                // Fetch associated passages from public.passages table
                val questionsWithPassages = try {
                    val qIds = questions.mapNotNull { it.id }
                    if (qIds.isNotEmpty()) {
                        val passagesRes = api.getPassagesForQuestions("in.(${qIds.joinToString(",")})")
                        if (passagesRes.isSuccessful) {
                            val passageMap = passagesRes.body().orEmpty()
                                .filter { it.questionId != null }
                                .associate { it.questionId!! to it.getEffectiveText() }
                            questions.map { q ->
                                val pText = q.id?.let { passageMap[it] }?.takeIf { it.isNotBlank() }
                                q.copy(passageText = pText)
                            }
                        } else {
                            questions
                        }
                    } else {
                        questions
                    }
                } catch (_: Exception) {
                    questions
                }
                Resource.Success(questionsWithPassages)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load questions: ${e.localizedMessage}")
        }
    }

    /**
     * Reliable Result Saving Logic
     * Works for Students, Admins, and Super Admins taking tests.
     */
    suspend fun submitResult(
        userId: Long,
        testId: Long,
        score: Double,
        userMobile: String = ""
    ): Resource<ResultItem> = withContext(Dispatchers.IO + NonCancellable) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase is not configured. Please check connection.")
        }
        val api = clientProvider.getApiService()

        // 1. Resolve effective User ID with 100% accuracy
        var effectiveUserId = userId
        if (effectiveUserId <= 0 && userMobile.isNotBlank()) {
            try {
                val userResp = api.getUserByMobile("eq.${userMobile.trim()}")
                if (userResp.isSuccessful) {
                    val foundUser = userResp.body()?.firstOrNull()
                    if (foundUser?.id != null && foundUser.id > 0) {
                        effectiveUserId = foundUser.id
                    }
                }
            } catch (_: Exception) {}
        }

        if (effectiveUserId <= 0) {
            return@withContext Resource.Error("User identification failed. Please log in again before submitting test.")
        }

        val createReq = CreateResultRequest(userId = effectiveUserId, testId = testId, score = score.toInt())
        val updateReq = UpdateResultRequest(score = score.toInt())
        var lastErrorMsg = "Unable to save result to Supabase server."
        var isNetError = false

        // 2. Perform saving with up to 3 automatic retry attempts
        for (attempt in 1..3) {
            try {
                // Step A: Check if this user already has a result for this test
                val checkResponse = api.getResultForUserAndTest("eq.$effectiveUserId", "eq.$testId")
                if (checkResponse.isSuccessful) {
                    val existingRows = checkResponse.body().orEmpty()
                    if (existingRows.isNotEmpty()) {
                        // Matching row already exists: Update existing result row
                        val existingRow = existingRows.first()
                        val patchResp = if (existingRow.id != null && existingRow.id > 0) {
                            api.updateResultById("eq.${existingRow.id}", updateReq)
                        } else {
                            api.updateResult("eq.$effectiveUserId", "eq.$testId", updateReq)
                        }
                        if (patchResp.isSuccessful && !patchResp.body().isNullOrEmpty()) {
                            return@withContext Resource.Success(patchResp.body()!!.first())
                        } else if (!patchResp.isSuccessful) {
                            lastErrorMsg = extractErrorMessage(patchResp)
                        }
                    } else {
                        // No existing row: Perform INSERT into results table
                        val insertResp = api.submitResult(createReq)
                        if (insertResp.isSuccessful && !insertResp.body().isNullOrEmpty()) {
                            return@withContext Resource.Success(insertResp.body()!!.first())
                        } else if (insertResp.isSuccessful) {
                            val verifyResp = api.getResultForUserAndTest("eq.$effectiveUserId", "eq.$testId")
                            if (verifyResp.isSuccessful && !verifyResp.body().isNullOrEmpty()) {
                                return@withContext Resource.Success(verifyResp.body()!!.first())
                            }
                        } else {
                            lastErrorMsg = extractErrorMessage(insertResp)
                        }
                    }
                } else {
                    lastErrorMsg = extractErrorMessage(checkResponse)
                }

                // Step B: Fallback attempt with direct Upsert or Update
                val upsertResp = try {
                    api.upsertResult(onConflict = "user_id,test_id", result = createReq)
                } catch (_: Exception) { null }
                if (upsertResp != null && upsertResp.isSuccessful && !upsertResp.body().isNullOrEmpty()) {
                    return@withContext Resource.Success(upsertResp.body()!!.first())
                }

                val directPatch = api.updateResult("eq.$effectiveUserId", "eq.$testId", updateReq)
                if (directPatch.isSuccessful && !directPatch.body().isNullOrEmpty()) {
                    return@withContext Resource.Success(directPatch.body()!!.first())
                }

                // Step C: Direct verification query on Supabase to verify presence of result
                val finalVerification = api.getResultForUserAndTest("eq.$effectiveUserId", "eq.$testId")
                if (finalVerification.isSuccessful && !finalVerification.body().isNullOrEmpty()) {
                    val confirmedItem = finalVerification.body()!!.first()
                    return@withContext Resource.Success(confirmedItem)
                }
            } catch (e: IOException) {
                isNetError = true
                lastErrorMsg = "Internet connection error while saving result: ${e.localizedMessage}"
            } catch (e: Exception) {
                lastErrorMsg = e.localizedMessage ?: "Unexpected error during result save"
            }
            if (attempt < 3) {
                delay(attempt * 400L)
            }
        }

        Resource.Error(
            message = if (isNetError) "No internet connection. Result could not be saved to Supabase: $lastErrorMsg" else lastErrorMsg,
            isNetworkError = isNetError
        )
    }

    suspend fun getStudentResults(userId: Long, userMobile: String = ""): Resource<List<EnrichedResult>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            var effectiveUserId = userId
            if (effectiveUserId <= 0 && userMobile.isNotBlank()) {
                try {
                    val userResp = api.getUserByMobile("eq.${userMobile.trim()}")
                    if (userResp.isSuccessful) {
                        effectiveUserId = userResp.body()?.firstOrNull()?.id ?: 0L
                    }
                } catch (_: Exception) {}
            }

            val resultsResp = if (effectiveUserId > 0) {
                api.getResultsForUser("eq.$effectiveUserId")
            } else {
                api.getResults(select = "*", order = "id.desc")
            }
            val testsResp = try { api.getTests(order = "id.asc") } catch (_: Exception) { null }

            if (resultsResp.isSuccessful) {
                val results = resultsResp.body().orEmpty()
                val testsMap = testsResp?.body().orEmpty().associateBy { it.id ?: 0L }
                val distinctResults = results.distinctBy { it.testId }
                val enriched = distinctResults.map { res ->
                    val test = testsMap[res.testId]
                    EnrichedResult(
                        id = res.id,
                        userId = res.userId,
                        userMobile = userMobile,
                        testId = res.testId,
                        testName = test?.testName ?: "Test #${res.testId}",
                        testDuration = test?.duration ?: 0,
                        score = res.score,
                        createdAt = res.createdAt
                    )
                }
                Resource.Success(enriched)
            } else {
                Resource.Error(extractErrorMessage(resultsResp))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load results: ${e.localizedMessage}")
        }
    }

    /**
     * Complete Results Table Query for Admin & Super Admin (from TEST MITRA RESULTS)
     */
    suspend fun getResultsForTestAdmin(testId: Long, testTotalMarks: Double? = null): Resource<List<ResultModel>> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()

            // Preload users cache if empty
            if (usersNameCache.isEmpty()) {
                val usersResp = api.getAllUsers()
                if (usersResp.isSuccessful) {
                    usersResp.body().orEmpty().forEach { u ->
                        if (u.id != null) {
                            usersNameCache[u.id] = u.name ?: u.mobileNumber
                        }
                    }
                }
            }

            val response = api.getResultsForTest("eq.$testId")
            if (response.isSuccessful) {
                val results = response.body().orEmpty()
                val mapped = results.mapIndexed { idx, item ->
                    val studentName = usersNameCache[item.userId] ?: "Student #${item.userId}"
                    ResultModel(
                        id = item.id?.toString() ?: idx.toString(),
                        testId = testId.toString(),
                        studentName = studentName,
                        score = item.score,
                        totalMarks = testTotalMarks,
                        createdAt = item.createdAt
                    )
                }.sortedByDescending { it.score }
                Resource.Success(mapped)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection. Please check your network.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to load test results: ${e.localizedMessage}")
        }
    }

    private fun normalizeDateForDb(dateStr: String?): String? {
        if (dateStr.isNullOrBlank()) return null
        val clean = dateStr.trim()
        val dmyRegex = Regex("""^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$""")
        val match = dmyRegex.find(clean)
        if (match != null) {
            val (d, m, y) = match.destructured
            return String.format(java.util.Locale.US, "%04d-%02d-%02d", y.toInt(), m.toInt(), d.toInt())
        }
        return clean
    }

    suspend fun createTest(
        testName: String,
        durationMinutes: Int,
        testDate: String? = null,
        testDay: String? = null
    ): Resource<TestItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val cleanName = testName.trim()
            val cleanDate = normalizeDateForDb(testDate)
            val cleanDay = testDay?.trim()?.ifBlank { null }
            val api = clientProvider.getApiService()
            val req = CreateTestRequest(
                testName = cleanName,
                duration = durationMinutes,
                isActive = true,
                testDate = cleanDate,
                testDay = cleanDay
            )
            val response = api.createTest(req)
            if (response.isSuccessful) {
                val created = response.body()?.firstOrNull() ?: TestItem(
                    testName = cleanName,
                    duration = durationMinutes,
                    isActive = true,
                    testDate = cleanDate,
                    testDay = cleanDay
                )
                Resource.Success(created)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to create test.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to create test: ${e.localizedMessage}")
        }
    }

    suspend fun updateTest(
        testId: Long,
        testName: String,
        durationMinutes: Int,
        testDate: String? = null,
        testDay: String? = null
    ): Resource<TestItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val cleanName = testName.trim()
            val cleanDate = normalizeDateForDb(testDate)
            val cleanDay = testDay?.trim()?.ifBlank { null }
            val api = clientProvider.getApiService()
            val req = UpdateTestRequest(
                testName = cleanName,
                duration = durationMinutes,
                testDate = cleanDate,
                testDay = cleanDay
            )
            val response = api.updateTest("eq.$testId", req)
            if (response.isSuccessful) {
                val updated = response.body()?.firstOrNull() ?: TestItem(
                    id = testId,
                    testName = cleanName,
                    duration = durationMinutes,
                    testDate = cleanDate,
                    testDay = cleanDay
                )
                Resource.Success(updated)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to update test.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update test: ${e.localizedMessage}")
        }
    }

    suspend fun deleteTest(testId: Long, callerUser: User? = null): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can delete tests.")
        }
        try {
            val api = clientProvider.getApiService()

            // 1 & 2. Read and save question.id and image_url for every question belonging to this test
            val questionsRes = api.getQuestionsForTest("eq.$testId")
            if (!questionsRes.isSuccessful) {
                return@withContext Resource.Error(extractErrorMessage(questionsRes))
            }
            val questions = questionsRes.body().orEmpty()

            for (q in questions) {
                val qId = q.id
                val imgUrl = q.imageUrl?.trim()?.takeIf { it.isNotEmpty() }

                // 3. Delete the Passage belonging to that Question: passages.question_id = question.id
                if (qId != null) {
                    try {
                        api.deletePassageForQuestion("eq.$qId")
                    } catch (e: Exception) {
                        android.util.Log.w("TestMitraRepository", "Failed to delete passage for question $qId: ${e.localizedMessage}")
                    }
                }

                // 4. Delete the Question's Image from Supabase Storage bucket: question-images
                if (!imgUrl.isNullOrBlank()) {
                    val delRes = deleteQuestionImage(imgUrl)
                    if (delRes.isFailure) {
                        val err = delRes.exceptionOrNull()?.localizedMessage ?: "Failed to delete question image"
                        android.util.Log.e("TestMitraRepository", "Cannot delete test $testId: image deletion failed for question #$qId: $err")
                        return@withContext Resource.Error("Image deletion failed for question #$qId: $err")
                    }
                }
            }

            // 5. Then continue with the existing Test & Question deletion
            val response = api.deleteTest("eq.$testId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete test: ${e.localizedMessage}")
        }
    }

    suspend fun addQuestion(
        testId: Long,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: String,
        imageUrl: String? = null,
        passageText: String? = null
    ): Resource<QuestionItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val cleanImageUrl = imageUrl?.trim()?.takeIf { it.isNotEmpty() }
            val cleanPassage = passageText?.trim()?.takeIf { it.isNotEmpty() }

            // 1. Question save first
            val req = CreateQuestionRequest(
                testId = testId,
                questionText = questionText.trim(),
                optionA = optionA.trim(),
                optionB = optionB.trim(),
                optionC = optionC.trim(),
                optionD = optionD.trim(),
                correctOption = correctOption.trim().uppercase(),
                imageUrl = cleanImageUrl
            )
            val response = api.createQuestion(req)
            if (response.isSuccessful) {
                var created = response.body()?.firstOrNull() ?: QuestionItem(
                    testId = testId,
                    questionText = questionText,
                    optionA = optionA,
                    optionB = optionB,
                    optionC = optionC,
                    optionD = optionD,
                    correctOption = correctOption,
                    imageUrl = cleanImageUrl
                )

                // Get question ID
                val qId = created.id ?: run {
                    val freshRes = api.getQuestionsForTest("eq.$testId")
                    freshRes.body().orEmpty().lastOrNull { it.questionText == questionText.trim() }?.id
                }

                // 2. If passage provided, insert into public.passages with question_id
                if (cleanPassage != null && qId != null) {
                    try {
                        val passRes = api.createPassage(
                            CreatePassageRequest(
                                questionId = qId,
                                passage = cleanPassage
                            )
                        )
                        if (!passRes.isSuccessful && passRes.code() == 409) {
                            api.updatePassage("eq.$qId", UpdatePassageRequest(passage = cleanPassage))
                        }
                    } catch (_: Exception) {
                        // Safe fallback
                    }
                }

                Resource.Success(created.copy(id = qId ?: created.id, passageText = cleanPassage, imageUrl = cleanImageUrl))
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to save question.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to save question: ${e.localizedMessage}")
        }
    }

    suspend fun updateQuestion(
        questionId: Long,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: String,
        imageUrl: String? = null,
        passageText: String? = null,
        oldImageUrlToDelete: String? = null
    ): Resource<QuestionItem> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        try {
            val api = clientProvider.getApiService()
            val cleanImageUrl = imageUrl?.trim()?.takeIf { it.isNotEmpty() }
            val cleanPassage = passageText?.trim()?.takeIf { it.isNotEmpty() }

            // Construct JSON payload: explicitly emits `"image_url": null` when removing image
            val json = JSONObject().apply {
                put("question_text", questionText.trim())
                put("option_a", optionA.trim())
                put("option_b", optionB.trim())
                put("option_c", optionC.trim())
                put("option_d", optionD.trim())
                put("correct_option", correctOption.trim().uppercase())
                if (cleanImageUrl != null) {
                    put("image_url", cleanImageUrl)
                } else {
                    put("image_url", JSONObject.NULL)
                }
            }
            val requestBody = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
            val response = api.updateQuestionRaw("eq.$questionId", requestBody)
            if (response.isSuccessful) {
                val updated = response.body()?.firstOrNull() ?: QuestionItem(
                    id = questionId,
                    testId = 0L,
                    questionText = questionText,
                    optionA = optionA,
                    optionB = optionB,
                    optionC = optionC,
                    optionD = optionD,
                    correctOption = correctOption,
                    imageUrl = cleanImageUrl
                )

                // If an old image is being removed or replaced, delete the old file from Supabase Storage
                // AFTER the database update succeeds, without silently swallowing errors.
                val oldImageClean = oldImageUrlToDelete?.trim()?.takeIf { it.isNotEmpty() }
                if (oldImageClean != null) {
                    val delRes = deleteQuestionImage(oldImageClean)
                    if (delRes.isFailure) {
                        android.util.Log.w("TestMitraRepository", "Question updated in DB, but old image deletion failed: ${delRes.exceptionOrNull()?.localizedMessage}")
                    }
                }

                // Manage passage in public.passages table:
                // - Passage edit -> UPDATE
                // - Passage remove -> DELETE record
                // - Passage added -> INSERT
                try {
                    val existingRes = api.getPassagesForQuestion("eq.$questionId")
                    val existing = existingRes.body().orEmpty().firstOrNull()

                    if (cleanPassage == null) {
                        if (existing != null) {
                            api.deletePassageForQuestion("eq.$questionId")
                        }
                    } else {
                        if (existing != null) {
                            api.updatePassage("eq.$questionId", UpdatePassageRequest(passage = cleanPassage))
                        } else {
                            api.createPassage(CreatePassageRequest(questionId = questionId, passage = cleanPassage))
                        }
                    }
                } catch (_: Exception) {
                    // Safe fallback
                }

                Resource.Success(updated.copy(passageText = cleanPassage, imageUrl = cleanImageUrl))
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection to update question.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to update question: ${e.localizedMessage}")
        }
    }

    suspend fun deleteQuestion(
        questionId: Long,
        callerUser: User? = null,
        imageUrl: String? = null
    ): Resource<Unit> = withContext(Dispatchers.IO) {
        if (!clientProvider.isConfigured()) {
            return@withContext Resource.Error("Supabase not configured")
        }
        if (callerUser != null && !callerUser.isSuperAdminUser) {
            return@withContext Resource.Error("Permission denied: Only Super Admin can delete questions.")
        }
        try {
            val api = clientProvider.getApiService()

            // 1. If question has an associated image, delete it from Supabase Storage
            var imageToDelete = imageUrl?.trim()?.takeIf { it.isNotEmpty() }
            if (imageToDelete == null) {
                try {
                    val qRes = api.getQuestionById("eq.$questionId")
                    imageToDelete = qRes.body()?.firstOrNull()?.imageUrl?.trim()?.takeIf { it.isNotEmpty() }
                } catch (_: Exception) {}
            }

            if (!imageToDelete.isNullOrBlank()) {
                val delRes = deleteQuestionImage(imageToDelete)
                if (delRes.isFailure) {
                    val err = delRes.exceptionOrNull()?.localizedMessage ?: "Failed to delete question image"
                    android.util.Log.e("TestMitraRepository", "Cannot delete question $questionId: image deletion failed: $err")
                    return@withContext Resource.Error("Image deletion failed: $err")
                }
            }

            try {
                api.deletePassageForQuestion("eq.$questionId")
            } catch (_: Exception) {}
            val response = api.deleteQuestion("eq.$questionId")
            if (response.isSuccessful) {
                Resource.Success(Unit)
            } else {
                Resource.Error(extractErrorMessage(response))
            }
        } catch (e: IOException) {
            Resource.Error("No internet connection.", isNetworkError = true)
        } catch (e: Exception) {
            Resource.Error("Unable to delete question: ${e.localizedMessage}")
        }
    }

    suspend fun uploadQuestionImage(uri: Uri, context: Context): Result<String> {
        val storageManager = SupabaseStorageManager(clientProvider, context)
        return storageManager.uploadQuestionImage(uri)
    }

    suspend fun deleteQuestionImage(imageUrlOrPath: String?): Result<Unit> {
        val storageManager = SupabaseStorageManager(clientProvider)
        return storageManager.deleteQuestionImage(imageUrlOrPath)
    }
}
