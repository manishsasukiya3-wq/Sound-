package com.example.data.remote

import com.example.data.model.CreatePassageRequest
import com.example.data.model.CreateQuestionRequest
import com.example.data.model.CreateResultRequest
import com.example.data.model.CreateTestRequest
import com.example.data.model.CreateUserRequest
import com.example.data.model.PassageItem
import com.example.data.model.QuestionItem
import com.example.data.model.ResultItem
import com.example.data.model.TestItem
import com.example.data.model.UpdatePassageRequest
import com.example.data.model.UpdateQuestionRequest
import com.example.data.model.UpdateResultRequest
import com.example.data.model.UpdateTestRequest
import com.example.data.model.UpdateTestStatusRequest
import com.example.data.model.UpdateUserDeviceRequest
import com.example.data.model.UpdateUserRequest
import com.example.data.model.User
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.PATCH
import retrofit2.http.POST
import retrofit2.http.Query

interface SupabaseApiService {

    // USERS Table
    @GET("users")
    suspend fun getUserByMobile(
        @Query("mobile_number") mobileNumberFilter: String, // e.g. "eq.9876543210"
        @Query("select") select: String = "*"
    ): Response<List<User>>

    @GET("users")
    suspend fun getUserById(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*"
    ): Response<List<User>>

    @GET("users")
    suspend fun getAllUsers(
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.asc"
    ): Response<List<User>>

    @Headers("Prefer: return=representation")
    @POST("users")
    suspend fun createUser(
        @Body user: CreateUserRequest
    ): Response<List<User>>

    @Headers("Prefer: return=representation")
    @PATCH("users")
    suspend fun updateUserDeviceId(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Body body: UpdateUserDeviceRequest
    ): Response<List<User>>

    @Headers("Prefer: return=representation")
    @PATCH("users")
    suspend fun updateUser(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Body body: UpdateUserRequest
    ): Response<List<User>>

    @DELETE("users")
    suspend fun deleteUser(
        @Query("id") idFilter: String // e.g. "eq.1"
    ): Response<Unit>

    // TESTS Table
    @GET("tests")
    suspend fun getTests(
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.desc"
    ): Response<List<TestItem>>

    @GET("tests")
    suspend fun getTestById(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*"
    ): Response<List<TestItem>>

    @Headers("Prefer: return=representation")
    @POST("tests")
    suspend fun createTest(
        @Body test: CreateTestRequest
    ): Response<List<TestItem>>

    @Headers("Prefer: return=representation")
    @PATCH("tests")
    suspend fun updateTestStatus(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Body body: UpdateTestStatusRequest
    ): Response<List<TestItem>>

    @Headers("Prefer: return=representation")
    @PATCH("tests")
    suspend fun updateTest(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Body body: UpdateTestRequest
    ): Response<List<TestItem>>

    @DELETE("tests")
    suspend fun deleteTest(
        @Query("id") idFilter: String
    ): Response<Unit>

    // QUESTIONS Table
    @GET("questions")
    suspend fun getQuestionsForTest(
        @Query("test_id") testIdFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.asc"
    ): Response<List<QuestionItem>>

    @GET("questions")
    suspend fun getQuestionById(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*"
    ): Response<List<QuestionItem>>

    @GET("questions")
    suspend fun getAllQuestions(
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.asc"
    ): Response<List<QuestionItem>>

    @Headers("Prefer: return=representation")
    @POST("questions")
    suspend fun createQuestion(
        @Body question: CreateQuestionRequest
    ): Response<List<QuestionItem>>

    @Headers("Prefer: return=representation")
    @PATCH("questions")
    suspend fun updateQuestion(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Body body: UpdateQuestionRequest
    ): Response<List<QuestionItem>>

    @Headers("Prefer: return=representation", "Content-Type: application/json")
    @PATCH("questions")
    suspend fun updateQuestionRaw(
        @Query("id") idFilter: String, // e.g. "eq.1"
        @Body body: RequestBody
    ): Response<List<QuestionItem>>

    @DELETE("questions")
    suspend fun deleteQuestion(
        @Query("id") idFilter: String
    ): Response<Unit>

    // PASSAGES Table (public.passages)
    @GET("passages")
    suspend fun getPassagesForQuestion(
        @Query("question_id") questionIdFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*"
    ): Response<List<PassageItem>>

    @GET("passages")
    suspend fun getPassagesForQuestions(
        @Query("question_id") questionIdsFilter: String, // e.g. "in.(1,2,3)"
        @Query("select") select: String = "*"
    ): Response<List<PassageItem>>

    @Headers("Prefer: return=representation")
    @POST("passages")
    suspend fun createPassage(
        @Body passage: CreatePassageRequest
    ): Response<List<PassageItem>>

    @Headers("Prefer: return=representation")
    @PATCH("passages")
    suspend fun updatePassage(
        @Query("question_id") questionIdFilter: String, // e.g. "eq.1"
        @Body body: UpdatePassageRequest
    ): Response<List<PassageItem>>

    @DELETE("passages")
    suspend fun deletePassageForQuestion(
        @Query("question_id") questionIdFilter: String // e.g. "eq.1"
    ): Response<Unit>

    // RESULTS Table
    @GET("results")
    suspend fun getResults(
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.desc"
    ): Response<List<ResultItem>>

    @GET("results")
    suspend fun getResultsForTest(
        @Query("test_id") testIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.desc"
    ): Response<List<ResultItem>>

    @GET("results")
    suspend fun getResultsForUser(
        @Query("user_id") userIdFilter: String, // e.g. "eq.1"
        @Query("select") select: String = "*",
        @Query("order") order: String = "id.desc"
    ): Response<List<ResultItem>>

    @GET("results")
    suspend fun getResultForUserAndTest(
        @Query("user_id") userIdFilter: String, // e.g. "eq.1"
        @Query("test_id") testIdFilter: String, // e.g. "eq.5"
        @Query("select") select: String = "*"
    ): Response<List<ResultItem>>

    @Headers("Prefer: return=representation")
    @POST("results")
    suspend fun submitResult(
        @Body result: CreateResultRequest
    ): Response<List<ResultItem>>

    @Headers("Prefer: resolution=merge-duplicates,return=representation")
    @POST("results")
    suspend fun upsertResult(
        @Query("on_conflict") onConflict: String = "user_id,test_id",
        @Body result: CreateResultRequest
    ): Response<List<ResultItem>>

    @Headers("Prefer: return=representation")
    @PATCH("results")
    suspend fun updateResult(
        @Query("user_id") userIdFilter: String, // e.g. "eq.1"
        @Query("test_id") testIdFilter: String, // e.g. "eq.5"
        @Body body: UpdateResultRequest
    ): Response<List<ResultItem>>

    @Headers("Prefer: return=representation")
    @PATCH("results")
    suspend fun updateResultById(
        @Query("id") idFilter: String, // e.g. "eq.10"
        @Body body: UpdateResultRequest
    ): Response<List<ResultItem>>

    @DELETE("results")
    suspend fun deleteResult(
        @Query("id") idFilter: String
    ): Response<Unit>
}
